   <footer class="app-footer">
       <!--begin::To the end-->
       {{-- <div class="float-end d-none d-sm-inline">أي شيء تريده</div> --}}
       <!--end::To the end-->
       <!--begin::Copyright-->
       <strong>
           {{-- <a href="https://adminlte.io" class="text-decoration-none">نظام التحفيظ</a>. --}}
       </strong>
       <!--end::Copyright-->
   </footer>
